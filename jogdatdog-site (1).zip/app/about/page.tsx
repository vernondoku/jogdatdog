import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import BookButton from "@/components/BookButton";
import { FinalCTA } from "@/components/sections";
import { site } from "@/data/site";
import Img from "@/components/Img";

export const metadata: Metadata = {
  title: "About Us — Kansas City's Mobile Dog Gym",
  description: "Jog Dat Dog started with a simple idea: most dogs don't get enough real exercise, so we built a gym that drives to them. Meet the team behind Kansas City's mobile dog gym.",
  alternates: { canonical: "/about/" },
};

const Check = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#84C06C" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className="shrink-0"><path d="m5 13 4 4L19 7" /></svg>;

export default function Page() {
  return (
    <>
      <PageHero kick="About Us" title={<>Our <span className="text-lime">story</span></>}
        blurb="Jog Dat Dog started with a simple idea: most dogs don't get enough real exercise, and most owners don't have the time or the space to fix that. So we built a gym that drives to them."
        img="founder" alt="Founder Vernon sitting in the open door of the Jog Dat Dog van" placement="about_hero" />
      <div className="bg-bone text-navy">
        <section className="wrap pt-16 pb-6 grid md:grid-cols-3 gap-5 items-start">
          <div className="card-light p-7 flex flex-col gap-3"><span className="inline-flex w-[52px] h-[52px] rounded-2xl bg-navy items-center justify-center"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#84C06C" strokeWidth="2.4" strokeLinecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="4" /><path d="M12 3v3M12 18v3M3 12h3M18 12h3" /></svg></span><strong className="disp not-italic text-[28px]">Our mission</strong><p className="text-muted-dark m-0 leading-relaxed">A happier, healthier, more fulfilled dog — without the owner leaving home. Structured exercise, enrichment, and training that fits real life.</p></div>
          <div className="card-light p-7 flex flex-col gap-3"><span className="inline-flex w-[52px] h-[52px] rounded-2xl bg-navy items-center justify-center"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#84C06C" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 9l4-5h10l4 5-9 12z" /><path d="M3 9h18M9 4l3 17 3-17" /></svg></span><strong className="disp not-italic text-[28px]">Our difference</strong><p className="text-muted-dark m-0 leading-relaxed">A mobile gym with dog-powered slatmills, plus professional in-home training — one team, one van, tailored to your dog.</p></div>
          <div className="card-light p-7 flex flex-col gap-3"><span className="inline-flex w-[52px] h-[52px] rounded-2xl bg-navy items-center justify-center"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#84C06C" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 11c0 5.5-7 10-7 10z" /></svg></span><strong className="disp not-italic text-[28px]">Our values</strong>{["Dog-first approach", "Safety and trust", "Convenience", "Owners in the loop"].map((t) => <div key={t} className="flex gap-2.5 items-center font-medium"><Check />{t}</div>)}</div>
        </section>
        <section className="wrap py-7 pb-20 grid lg:grid-cols-2 gap-5 items-stretch">
          <Img name="van" alt="The Jog Dat Dog van parked on a Kansas City street" sizes="(min-width: 1024px) 50vw, 100vw" className="w-full h-[300px] lg:h-[380px] object-cover object-[center_55%] rounded-[18px]" />
          <div className="card-light p-7 flex flex-col gap-3.5">
            <p className="kick text-teal-dark m-0">The team</p>
            <strong className="disp not-italic text-[32px]">Who shows up at your door</strong>
            <p className="text-muted-dark m-0 leading-relaxed">[Founder story in your words — when you started, why slatmills, the first dog. 3–4 sentences.]</p>
            <p className="text-muted-dark m-0 leading-relaxed">{site.serviceAreaBlurb} Supporting local rescues through the Helping Paws program — donate a run at booking.</p>
            <BookButton placement="about_cta" className="self-start mt-auto" />
          </div>
        </section>
      </div>
      <FinalCTA placement="about_final" />
    </>
  );
}
