import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import BookButton from "@/components/BookButton";
import { PackGrid } from "@/components/sections";

export const metadata: Metadata = {
  title: "Meet the Pack — Real Jog Dat Dog Runners",
  description: "The real stars of Jog Dat Dog: Kansas City dogs who run with us every week. Real pups, real workouts, big personalities.",
  alternates: { canonical: "/our-pack/" },
};

export default function Page() {
  return (
    <>
      <PageHero kick="03 / The starting lineup" title={<>Meet the <span className="text-lime">pack</span></>}
        blurb="The real stars of Jog Dat Dog. Real pups, real workouts, big personalities." placement="pack_hero" cta="Book your first run" compact />
      <div className="bg-bone text-navy">
        <section className="wrap py-12 md:py-16 flex flex-col gap-8">
          <PackGrid />
          <div className="band rounded-[20px] p-7 md:p-8 flex items-center justify-between gap-5 flex-wrap">
            <div><strong className="disp text-[32px] text-white">Want your dog on the roster?</strong><p className="m-0 mt-1 text-bone-mid">Every pack member started with one intro run.</p></div>
            <BookButton placement="pack_cta">Book your first run</BookButton>
          </div>
        </section>
      </div>
    </>
  );
}
